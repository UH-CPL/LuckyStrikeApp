//
//  ViewController.swift
//  LuckyStrike
//
//  Created by Ioannis Pavlidis on 9/1/20.
//  Copyright © 2020 Ioannis Pavlidis. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var leftDiceImage: UIImageView!
    
    @IBOutlet weak var rightDiceImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        rightDiceImage.image = #imageLiteral(resourceName: "Dice2")
        
    }

    
    @IBAction func throwPressedButton(_ sender: Any) {
        
        let diceArray = [#imageLiteral(resourceName: "Dice1"), #imageLiteral(resourceName: "Dice2"), #imageLiteral(resourceName: "Dice3"), #imageLiteral(resourceName: "Dice4"), #imageLiteral(resourceName: "Dice5"), #imageLiteral(resourceName: "Dice6")]
    
        leftDiceImage.image = diceArray[Int .random(in: 0...5)]
        rightDiceImage.image = diceArray[Int .random(in: 0...5)]
    }
}

